/* teatex.c  */

/* Author: Matt Evett modified teatex.c by E. Angel, from Interactive Computer Graphics */
/* A Top-Down Approach with OpenGL, Third Edition */
/* Addison-Wesley Longman, 2003 */
/* Evett, 2006

/* Utah teapot with texture map  */

#include <stdlib.h>
#include <GLUT/glut.h>
#include <stdio.h>



static GLfloat theta[] = {0.0,0.0,0.0};
static GLint axis = 2;
static GLint textureSampling = GL_NEAREST;
static GLint wrappingMode = GL_REPEAT;

void display(void)
{
/* display callback, clear frame buffer and z buffer,
   rotate cube and draw, swap buffers */

 glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	glRotatef(theta[0], 1.0, 0.0, 0.0);
	glRotatef(theta[1], 0.0, 1.0, 0.0);
	glRotatef(theta[2], 0.0, 0.0, 1.0);

	glutSolidTeapot(1.0);

    glBegin(GL_QUADS);
	glTexCoord2f(0.0,0.0);
	glVertex3f(0,0,0);
	glTexCoord2f(1.5,0.0);
	glVertex3f(2,0,0);
	glTexCoord2f(1.5,1.5);
	glVertex3f(2,2,-1);
	glTexCoord2f(0.0,1.5);
	glVertex3f(0,2,-1);
	glEnd();
	

	glutSwapBuffers();
}

void spinTeapot()
{

/* Idle callback, spin cube 2 degrees about selected axis */

	theta[axis] += 2.0;
	if( theta[axis] > 360.0 ) theta[axis] -= 360.0;
	glutPostRedisplay();
}

void mouse(int btn, int state, int x, int y)
{

/* mouse callback, selects an axis about which to rotate */

	if(btn==GLUT_LEFT_BUTTON && state == GLUT_DOWN) axis = 0;
	if(btn==GLUT_MIDDLE_BUTTON && state == GLUT_DOWN) axis = 1;
	if(btn==GLUT_RIGHT_BUTTON && state == GLUT_DOWN) axis = 2;
}

void myReshape(int w, int h)
{
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    if (w <= h)
        glOrtho(-2.0, 2.0, -2.0 * (GLfloat) h / (GLfloat) w,
            2.0 * (GLfloat) h / (GLfloat) w, -10.0, 10.0);
    else
        glOrtho(-2.0 * (GLfloat) w / (GLfloat) h,
            2.0 * (GLfloat) w / (GLfloat) h, -2.0, 2.0, -10.0, 10.0);
    glMatrixMode(GL_MODELVIEW);
}

void key(char k, int x, int y)
{
	if (k == 'q') exit(0);
	if(k == '1') glutIdleFunc(spinTeapot);
	if(k == '2') glutIdleFunc(NULL);
	if(k == '3') {
		textureSampling = (textureSampling == GL_LINEAR ? GL_NEAREST : GL_LINEAR);
		printf("textSamp = %d\n", textureSampling);
		}
	if(k == '4') {
		wrappingMode = (wrappingMode == GL_CLAMP ? GL_REPEAT : GL_CLAMP);
		printf("wrapping = %d\n", wrappingMode);
		}
   glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,wrappingMode);
   glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,wrappingMode);
   glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,textureSampling);
   glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,textureSampling); 


}

void
main(int argc, char **argv)
{

   printf("1 and 2 stop and start the rotations, 3 toggles the texture sampling between NEAREST and LINEAR\n");
   printf("4 toggles the texture wrapping between REPEAT and CLAMP.  The mouse buttons change the axes of rotation.  q to exit.\n");
   GLubyte image[64][64][3];
   int i, j, r, c;
   for(i=0;i<64;i++)
   {
     for(j=0;j<64;j++)
     {
       c = ((((i&0x8)==0)^((j&0x8))==0))*255;
       image[i][j][0]= (GLubyte) c;
       image[i][j][1]= (GLubyte) 0;
       image[i][j][2]= (GLubyte) c;
     }
   }
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(500, 500);
    glutCreateWindow("Textured Teapot");

/* need both double buffering and z buffer */

    glutReshapeFunc(myReshape);
    glutDisplayFunc(display);
   glutIdleFunc(spinTeapot);
   glutMouseFunc(mouse);
 glEnable(GL_DEPTH_TEST);
   glEnable(GL_TEXTURE_2D);
   glTexImage2D(GL_TEXTURE_2D,0,3,64,64,0,GL_RGB,GL_UNSIGNED_BYTE, image);
   glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,wrappingMode);
   glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,wrappingMode);
   glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,textureSampling);
   glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,textureSampling); 
	glutKeyboardFunc(key);
	glClearColor(1.0,1.0,1.0,1.0);
    glutMainLoop();
}
