public class Driver01 {	
    public static void main(String[] args) {
		Rect r1 = new Rect(3d, 5d);
		System.out.println(r1.display());
		
		Circle c2 = new Circle(2d);
		System.out.println(c2.display());
    }
	
	// How about to create 100 Rects and Circles then display them
	// You need 100 variables
	// You need 100 new()
	// You need 100 .display() 
	// Can you be lazy?
}	