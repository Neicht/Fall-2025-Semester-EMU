//https://www.baeldung.com/java-reflection
import java.lang.reflect.*;
public class Driver04 {
	
    public static void main(String[] args) {
		String[] objs = {"Rect", "Circle", "Circle", "Rect", "Circle", "Rect"};
		// quick dirty but very bad approack for fast illustration only, better use Tuple or class etc.
		Double[] vals = {3d,5d, 2d,-1d, 4d,-1d, 4d,6d, 3d,-1d, 1d,2d}; 
		
		Class<?> classR = null;
		Constructor<?> constructor = null;
		Object o = null;

		for (int i=0; i< objs.length; i++) {
			try {
				classR = Class.forName(objs[i]);
				if (objs[i].equals("Rect")) {
					constructor = classR.getConstructor(double.class, double.class);
					o = constructor.newInstance(vals[i*2], vals[i*2+1]);
				}
				else {
					constructor = classR.getConstructor(double.class);
					o = constructor.newInstance(vals[i*2]);
				}
				System.out.println(((Shape) o).display());
			}
			catch(Exception ee) {
				System.out.println(ee);
			}	
		}
    }
}