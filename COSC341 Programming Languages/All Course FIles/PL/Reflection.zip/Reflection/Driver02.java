public class Driver02 {
    public static void main(String[] args) {
		final int BOUND = 6;
		Shape[] shapes = new Shape[BOUND];

		shapes[0] = new Rect(3d, 5d);
		shapes[1] = new Circle(2d);
		shapes[2] = new Circle(4d);
		shapes[3] = new Rect(4d, 6d);
		shapes[4] = new Circle(3d);
		shapes[5] = new Rect(1d, 2d);

		for (int i=0; i< shapes.length; i++) {
			System.out.println(shapes[i].display());
		}

		// shapes[i].display(); identical name, signature -- overriding, suitable for loop
		// shapes[i].display(); MAGIC: somehow knows rect or circle object -- late binding
		
		// How about to create 100 Rects and Circles then display them
		// You need 1 variable
		// You need 100 --> 1
		// You need 1 .display()
		// Can you be more greedy?
    }
}