//https://www.baeldung.com/java-reflection
//https://www.geeksforgeeks.org/variable-arguments-varargs-in-java/
import java.lang.reflect.*;
public class Driver05 {
	
    public static void main(String[] args) {
		String[] objs = {"Rect", "Circle", "Circle", "Rect", "Circle", "Rect"};
		// quick dirty but very bad approack for fast illustration only, better use Tuple or class etc.
		Double[] vals = {3d,5d, 2d,-1d, 4d,-1d, 4d,6d, 3d,-1d, 1d,2d}; 
		
		Class<?> classR = null;
		Constructor<?> constructor = null;
		Object o = null;

		for (int i=0; i< objs.length; i++) {
			o = createR(objs[i], vals[i*2], vals[i*2+1]);
			System.out.println(((Shape) o).display());
		}
    }
	
	private static Object createR(String className, double... d) {
		Class<?> classR = null;
		Constructor<?> constructor = null;
		Object o = null;
		
		try {
			classR = Class.forName(className);
			if (className.equals("Rect")) {
				constructor = classR.getConstructor(double.class, double.class);
				o = constructor.newInstance(d[0], d[1]);
			}
			else {
				constructor = classR.getConstructor(double.class);
				o = constructor.newInstance(d[0]);
			}
		}
		catch(Exception ee) {
			System.out.println(ee);
		}	
		
		return o;
	}
}