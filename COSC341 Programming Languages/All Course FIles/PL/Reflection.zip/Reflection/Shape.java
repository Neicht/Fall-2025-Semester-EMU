public abstract class Shape {
	public abstract double area();
	abstract public String display();
}