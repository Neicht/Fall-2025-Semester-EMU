public class Rect extends Shape{
	double width, height;
	
	public Rect(double w, double h) {
		width = w;
		height = h;
	}
	
	public double area() {
		return width * height;
	}

	public String display() {
		return "Rectangle has area " + area();
	}
}